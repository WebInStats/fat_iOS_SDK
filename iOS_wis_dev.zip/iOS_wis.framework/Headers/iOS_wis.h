//
//  iOS_wis.h
//  iOS_wis
//
//  Created by Selin on 18/07/2017.
//  Copyright © 2017 WebInStats. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for iOS_wis.
FOUNDATION_EXPORT double iOS_wisVersionNumber;

//! Project version string for iOS_wis.
FOUNDATION_EXPORT const unsigned char iOS_wisVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOS_wis/PublicHeader.h>


